// Função para fazer o login
function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username && password) {
        // Salva o usuário e senha no LocalStorage
        localStorage.setItem('user', username);
        localStorage.setItem('password', password);

        // Exibe a seção de configurações e oculta o login
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('config-section').style.display = 'block';
        document.getElementById('login-message').textContent = ''; // Remove a mensagem de erro
        carregarPreferencias(); // Carregar as preferências após login
    } else {
        document.getElementById('login-message').textContent = 'Por favor, preencha ambos os campos.';
    }
}

// Função para fazer logout
function logout() {
    // Remove o usuário do LocalStorage
    localStorage.removeItem('user');
    localStorage.removeItem('password');

    // Exibe a seção de login e oculta as configurações
    document.getElementById('login-section').style.display = 'block';
    document.getElementById('config-section').style.display = 'none';
    document.getElementById('login-message').textContent = '';
}

// Função para carregar as preferências do LocalStorage
function carregarPreferencias() {
    const tema = localStorage.getItem('tema') || 'claro';
    const fonte = localStorage.getItem('fonte') || 'Arial';
    const layout = localStorage.getItem('layout') || 'compacto';

    // Aplicar as preferências ao carregar a página
    aplicarTema(tema);
    aplicarFonte(fonte);
    aplicarLayout(layout);

    // Atualizar os selects com as preferências salvas
    document.getElementById('tema-select').value = tema;
    document.getElementById('fonte-select').value = fonte;
    document.getElementById('layout-select').value = layout;
}

// Função para salvar as preferências no LocalStorage
function salvarPreferencias() {
    const tema = document.getElementById('tema-select').value;
    const fonte = document.getElementById('fonte-select').value;
    const layout = document.getElementById('layout-select').value;

    // Salvar as preferências no LocalStorage
    localStorage.setItem('tema', tema);
    localStorage.setItem('fonte', fonte);
    localStorage.setItem('layout', layout);

    // Aplicar as preferências
    aplicarTema(tema);
    aplicarFonte(fonte);
    aplicarLayout(layout);
}

// Função para aplicar o tema
function aplicarTema(tema) {
    if (tema === 'escuro') {
        document.body.classList.add('tema-escuro');
        document.body.classList.remove('tema-claro');
    } else {
        document.body.classList.add('tema-claro');
        document.body.classList.remove('tema-escuro');
    }
}

// Função para aplicar a fonte
function aplicarFonte(fonte) {
    document.body.style.fontFamily = fonte;
}

// Função para aplicar o layout
function aplicarLayout(layout) {
    if (layout === 'espacoso') {
        document.body.classList.add('layout-espacoso');
        document.body.classList.remove('layout-compacto');
    } else {
        document.body.classList.add('layout-compacto');
        document.body.classList.remove('layout-espacoso');
    }
}

// Evento para aplicar as preferências ao selecionar os options
document.getElementById('tema-select').addEventListener('change', salvarPreferencias);
document.getElementById('fonte-select').addEventListener('change', salvarPreferencias);
document.getElementById('layout-select').addEventListener('change', salvarPreferencias);

// Verificar se o usuário está logado ao carregar a página
window.onload = function() {
    if (localStorage.getItem('user')) {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('config-section').style.display = 'block';
        carregarPreferencias();
    } else {
        document.getElementById('login-section').style.display = 'block';
        document.getElementById('config-section').style.display = 'none';
    }
};

// Evento de login
document.getElementById('login-btn').addEventListener('click', login);

// Evento de logout
document.getElementById('logout-btn').addEventListener('click', logout);
