// Função para alternar entre tema claro e escuro e salvar a escolha no localStorage
document.getElementById('themeToggle').addEventListener('click', function() {
    let currentTheme = localStorage.getItem('theme');
    if (currentTheme === 'escuro') {
        document.body.classList.remove('escuro');
        document.body.classList.add('claro');
        localStorage.setItem('theme', 'claro');
    } else {
        document.body.classList.remove('claro');
        document.body.classList.add('escuro');
        localStorage.setItem('theme', 'escuro');
    }
});

// Carregar o tema salvo no localStorage quando a página for carregada
document.addEventListener('DOMContentLoaded', function() {
    let theme = localStorage.getItem('theme') || 'claro';
    document.body.classList.add(theme);
});

// Função para exibir campos dinâmicos no formulário com base no tipo de consulta selecionado
document.getElementById('tipoConsulta').addEventListener('change', function() {
    const tipoConsulta = this.value;
    const camposAdicionais = document.getElementById('camposAdicionais');
    camposAdicionais.innerHTML = ''; // Limpa os campos anteriores

    if (tipoConsulta === 'sugestao') {
        camposAdicionais.innerHTML = `<label for="sugestao">Detalhes da Sugestão:</label><textarea id="sugestao" name="sugestao" placeholder="Descreva sua sugestão aqui..."></textarea>`;
    } else if (tipoConsulta === 'problema') {
        camposAdicionais.innerHTML = `<label for="problema">Descreva o Problema Técnico:</label><textarea id="problema" name="problema" placeholder="Detalhe o problema técnico..."></textarea>`;
    } else if (tipoConsulta === 'outros') {
        camposAdicionais.innerHTML = `<label for="outros">Outros Detalhes:</label><textarea id="outros" name="outros" placeholder="Descreva o que deseja nos outros..."></textarea>`;
    }
});

// Função para validar o formulário, incluindo reCAPTCHA simulado
document.getElementById('formContato').addEventListener('submit', function(e) {
    e.preventDefault();

    // Validação simples para nome e e-mail
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const mensagem = document.getElementById('mensagem').value;

    // Palavras proibidas (exemplo)
    const palavrasProibidas = ['erro', 'problema', 'bug'];
    if (palavrasProibidas.some(p => mensagem.toLowerCase().includes(p))) {
        alert('A mensagem contém palavras proibidas!');
        return;
    }

    // ReCAPTCHA Simulado (verificação de resultado da soma)
    const captchaResposta = document.getElementById('captchaResposta').value;
    if (captchaResposta !== '10') {
        alert('Resposta do CAPTCHA incorreta!');
        return;
    }

    alert('Formulário enviado com sucesso!');
});

// Função para gerar e exibir o reCAPTCHA simulado
function gerarCaptcha() {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const respostaCorreta = num1 + num2;

    const captchaContainer = document.getElementById('captcha');
    captchaContainer.innerHTML = `
        <span>Quanto é ${num1} + ${num2}?</span>
        <input type="text" id="captchaResposta" placeholder="Sua resposta">
    `;
}
gerarCaptcha();
