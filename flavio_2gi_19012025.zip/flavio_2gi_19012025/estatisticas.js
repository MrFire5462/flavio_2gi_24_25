// Simulação de dados JSON de estatísticas
const dadosJSON = {
    "estatisticas": [
        { "mes": "Janeiro", "acessos": 300, "vendas": 150 },
        { "mes": "Fevereiro", "acessos": 250, "vendas": 120 },
        { "mes": "Março", "acessos": 350, "vendas": 200 },
        { "mes": "Abril", "acessos": 400, "vendas": 220 },
        { "mes": "Maio", "acessos": 500, "vendas": 300 }
    ]
};

// Carregar dados e exibir na página
function carregarEstatisticas() {
    // Preenche a lista de estatísticas
    const lista = document.getElementById('estatisticas-lista');
    dadosJSON.estatisticas.forEach(dado => {
        const item = document.createElement('li');
        item.innerHTML = `${dado.mes}: Acessos: ${dado.acessos} | Vendas: ${dado.vendas}`;
        lista.appendChild(item);
    });

    // Atualizar a barra de progresso
    atualizarBarraProgresso();
}

// Atualizar barra de progresso
function atualizarBarraProgresso() {
    const barra = document.getElementById('barra-progresso');
    let progresso = 0;
    const interval = setInterval(() => {
        progresso += 10;
        barra.style.width = `${progresso}%`;

        if (progresso >= 100) {
            clearInterval(interval);
        }
    }, 100); // Simula o carregamento de dados
}

// Função para desenhar gráfico com dados dinâmicos (sem bibliotecas)
function gerarGrafico(intervalo) {
    const canvas = document.getElementById('grafico');
    const ctx = canvas.getContext('2d');

    // Limpa o canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Filtra os dados com base no intervalo selecionado
    let dadosFiltrados = dadosJSON.estatisticas;
    if (intervalo === 'mensal') {
        // Exemplo de filtro para um intervalo mensal
        dadosFiltrados = dadosFiltrados.filter(dado => dado.mes === "Janeiro");
    }

    // Preparação dos dados para o gráfico
    const labels = dadosFiltrados.map(dado => dado.mes);
    const acessos = dadosFiltrados.map(dado => dado.acessos);
    const vendas = dadosFiltrados.map(dado => dado.vendas);

    // Define a largura do gráfico e o número de pontos
    const largura = canvas.width - 40;
    const altura = canvas.height - 40;
    const numPontos = dadosFiltrados.length;
    const margemX = 30;
    const margemY = 30;

    // Normalizar dados para ajustar ao gráfico
    const maxAcessos = Math.max(...acessos);
    const maxVendas = Math.max(...vendas);
    const escalaY = Math.max(maxAcessos, maxVendas) / altura;

    // Função para desenhar os eixos
    function desenharEixos() {
        ctx.beginPath();
        ctx.moveTo(margemX, margemY);
        ctx.lineTo(margemX, altura + margemY); // Eixo Y
        ctx.lineTo(largura + margemX, altura + margemY); // Eixo X
        ctx.strokeStyle = '#FFF';
        ctx.stroke();
    }

    // Função para desenhar a linha de dados
    function desenharLinha(dados, cor) {
        ctx.beginPath();
        ctx.moveTo(margemX, altura + margemY - dados[0] / escalaY);

        for (let i = 1; i < numPontos; i++) {
            const x = margemX + (largura / (numPontos - 1)) * i;
            const y = altura + margemY - dados[i] / escalaY;
            ctx.lineTo(x, y);
        }

        ctx.strokeStyle = cor;
        ctx.stroke();
    }

    // Função para desenhar os pontos
    function desenharPontos(dados, cor) {
        dados.forEach((dado, i) => {
            const x = margemX + (largura / (numPontos - 1)) * i;
            const y = altura + margemY - dado / escalaY;
            ctx.beginPath();
            ctx.arc(x, y, 5, 0, Math.PI * 2);
            ctx.fillStyle = cor;
            ctx.fill();
        });
    }

    // Desenha o gráfico
    desenharEixos();
    desenharLinha(acessos, '#FF0000');  // Linha de acessos (vermelho)
    desenharLinha(vendas, '#00FF00');   // Linha de vendas (verde)
    desenharPontos(acessos, '#FF0000');  // Pontos de acessos
    desenharPontos(vendas, '#00FF00');   // Pontos de vendas
}

// Lidar com o evento de mudança no intervalo de dados
document.getElementById('intervalo').addEventListener('change', (e) => {
    gerarGrafico(e.target.value);
});

// Quando a página carrega
window.onload = function() {
    carregarEstatisticas();
    gerarGrafico('semanal'); // Definir gráfico padrão como semanal
};
