// Função de ordenação QuickSort para ordenar imagens por título
function quickSort(arr) {
    if (arr.length <= 1) {
        return arr;
    }

    const pivot = arr[0];
    const left = [];
    const right = [];

    for (let i = 1; i < arr.length; i++) {
        if (arr[i].titulo < pivot.titulo) {
            left.push(arr[i]);
        } else {
            right.push(arr[i]);
        }
    }

    return [...quickSort(left), pivot, ...quickSort(right)];
}

// Função para carregar a galeria de imagens com base na categoria selecionada
function carregarGaleria(categoriaSelecionada = '') {
    // Dados de exemplo de imagens e categorias
    const dadosGaleria = [
        { categoria: "Fantasma", url: "Fantasma1.jpg", titulo: "Fantasma na Floresta" },
        { categoria: "Monstro", url: "Monstro2.jfif", titulo: "O Monstro do Lago" },
        { categoria: "Assombração", url: "Assombração3.jfif", titulo: "Assombração na Casa" },
        { categoria: "Fantasma", url: "Fantasma2.png", titulo: "Fantasma da Floresta" },
        { categoria: "Monstro", url: "Monstro3.jpg", titulo: "Monstro das Sombras" },
        { categoria: "Assombração", url: "Assombração4.jpg", titulo: "Assombração na Casa" }
    ];

    // Selecionar a secção de galeria
    const galeria = document.getElementById('galeria');
    galeria.innerHTML = ''; // Limpar a galeria antes de recarregar as imagens

    // Carregar favoritos do localStorage
    let favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];

    // Filtrar as imagens pela categoria, se selecionada
    const imagensFiltradas = categoriaSelecionada
        ? dadosGaleria.filter(imagem => imagem.categoria === categoriaSelecionada)
        : dadosGaleria;

    // Ordenar as imagens com QuickSort
    const imagensOrdenadas = quickSort(imagensFiltradas);

    // Criar as imagens e adicioná-las à galeria
    imagensOrdenadas.forEach(imagem => {
        const imagemContainer = document.createElement('div');
        imagemContainer.classList.add('imagem-container');
        imagemContainer.setAttribute('draggable', 'true'); // Permitir que a imagem seja arrastada
        imagemContainer.dataset.url = imagem.url; // Armazenar a URL da imagem para reorganização

        // Adicionar a imagem
        const imgElement = document.createElement('img');
        imgElement.src = imagem.url;
        imgElement.alt = imagem.titulo;
        imgElement.title = imagem.titulo;

        // Adicionar o ícone de favorito
        const favoritoIcon = document.createElement('span');
        favoritoIcon.classList.add('favorito');
        favoritoIcon.innerHTML = '❤️';

        // Verificar se a imagem está nos favoritos
        if (favoritos.includes(imagem.url)) {
            favoritoIcon.classList.add('favoritado'); // Marca como favoritado
        }

        // Marcar/desmarcar como favorito
        favoritoIcon.addEventListener('click', () => {
            if (favoritos.includes(imagem.url)) {
                // Remover dos favoritos
                favoritos = favoritos.filter(fav => fav !== imagem.url);
                favoritoIcon.classList.remove('favoritado'); // Remove a cor de favorito
            } else {
                // Adicionar aos favoritos
                favoritos.push(imagem.url);
                favoritoIcon.classList.add('favoritado'); // Adiciona a cor de favorito
            }

            // Salvar os favoritos no localStorage
            localStorage.setItem('favoritos', JSON.stringify(favoritos));
        });

        // Adicionar o ícone de favorito à imagem
        imagemContainer.appendChild(imgElement);
        imagemContainer.appendChild(favoritoIcon);

        // Adicionar a imagem à galeria
        galeria.appendChild(imagemContainer);
    });

    // Adicionar funcionalidade de arrastar e soltar
    const imagens = galeria.querySelectorAll('.imagem-container');

    imagens.forEach(imagem => {
        imagem.addEventListener('dragstart', (event) => {
            event.dataTransfer.setData('text/plain', event.target.dataset.url); // Passar a URL da imagem sendo arrastada
        });

        imagem.addEventListener('dragover', (event) => {
            event.preventDefault(); // Permitir o drop (soltar)
        });

        imagem.addEventListener('drop', (event) => {
            event.preventDefault();
            const urlArrastada = event.dataTransfer.getData('text/plain'); // Pegar a URL da imagem arrastada
            const imagemArrastada = [...imagens].find(img => img.dataset.url === urlArrastada); // Encontrar o elemento arrastado

            // Trocar a posição das imagens
            const imagemSolta = event.target;
            if (imagemArrastada && imagemSolta !== imagemArrastada) {
                // Encontrar as imagens dentro do container de galeria
                const galeriaContainer = document.getElementById('galeria');
                
                // Garantir que a imagem solta não seja a mesma que a imagem arrastada
                const allImages = Array.from(galeriaContainer.children);
                
                // Reposicionar as imagens na galeria
                const arrastadaIndex = allImages.indexOf(imagemArrastada);
                const soltaIndex = allImages.indexOf(imagemSolta);

                if (arrastadaIndex < soltaIndex) {
                    galeriaContainer.insertBefore(imagemArrastada, imagemSolta.nextSibling);
                } else {
                    galeriaContainer.insertBefore(imagemArrastada, imagemSolta);
                }
            }
        });
    });
}

// Função para carregar as categorias
function carregarCategorias() {
    const categorias = [...new Set([
        "Fantasma", "Monstro", "Assombração"
    ])]; // Adicionar manualmente as categorias ou usar o JSON de imagens para gerá-las

    const selectCategoria = document.getElementById('categoria');
    categorias.forEach(categoria => {
        const option = document.createElement('option');
        option.value = categoria;
        option.textContent = categoria;
        selectCategoria.appendChild(option);
    });

    // Adicionar um evento para filtrar as imagens ao selecionar uma categoria
    selectCategoria.addEventListener('change', (event) => {
        const categoriaSelecionada = event.target.value;
        carregarGaleria(categoriaSelecionada);  // Recarregar a galeria com a categoria selecionada
    });
}

// Chamar as funções ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    carregarCategorias();
    carregarGaleria(); // Carregar todas as imagens inicialmente
});
