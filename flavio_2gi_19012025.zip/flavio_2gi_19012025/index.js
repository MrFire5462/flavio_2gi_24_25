const menuLinks = document.querySelectorAll('nav ul li a');

menuLinks.forEach(link => {
    link.addEventListener('click', (event) => {
        const target = event.target.getAttribute('href');
        
        // Mostra uma mensagem de contagem regressiva
        const countdown = document.createElement('div');
        countdown.classList.add('countdown');
        countdown.innerText = "Redirecionando em 3 segundos...";
        document.body.appendChild(countdown);

        let seconds = 3;
        const interval = setInterval(() => {
            seconds--;
            countdown.innerText = `Redirecionando em ${seconds} segundos...`;
            if (seconds === 0) {
                clearInterval(interval);
                window.location.href = target;  // Realiza a navegação após a contagem regressiva
            }
        }, 1000);
    });
});
